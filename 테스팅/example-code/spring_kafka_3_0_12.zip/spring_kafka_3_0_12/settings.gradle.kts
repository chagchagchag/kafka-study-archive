rootProject.name = "spring_kafka_3_0_12"
