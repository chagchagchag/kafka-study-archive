package com.example.spring_kafka_3_0_12

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringKafka3012ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
